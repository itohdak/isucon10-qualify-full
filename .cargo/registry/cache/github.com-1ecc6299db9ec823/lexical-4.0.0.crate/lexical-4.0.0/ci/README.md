# CI

Continuous integration tests based off the [trust](https://github.com/japaric/trust) framework.

# License

All code in the following repository is derived from trust, and is dual-licensed under the MIT/Apache 2.0 license.
