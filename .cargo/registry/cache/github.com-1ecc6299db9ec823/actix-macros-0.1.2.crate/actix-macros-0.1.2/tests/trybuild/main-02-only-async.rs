#[actix_rt::main]
fn main() {
    futures_util::future::ready(()).await
}
