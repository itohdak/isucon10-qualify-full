#[actix_rt::test]
async fn my_test() {
    assert!(true);
}

fn main() {}
