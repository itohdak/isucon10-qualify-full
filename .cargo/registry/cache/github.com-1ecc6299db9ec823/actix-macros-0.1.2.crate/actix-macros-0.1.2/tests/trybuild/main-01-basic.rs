#[actix_rt::main]
async fn main() {
    println!("Hello world");
}
