# CHANGES

## 0.1.2 - 2020-05-18

### Changed

* Forward actix_rt::test arguments to test function [#127]

[#127]: https://github.com/actix/actix-net/pull/127
