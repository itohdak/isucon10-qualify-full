# Changes

## [1.0.0] - 2019-12-11

* 1.0.0 release

## [1.0.0-alpha.3] - 2019-12-07

### Changed

* Migrate to tokio 0.2

* Enable rustls acceptor service

* Enable native-tls acceptor service

## [1.0.0-alpha.1] - 2019-12-02

* Split openssl accetor from actix-server package
