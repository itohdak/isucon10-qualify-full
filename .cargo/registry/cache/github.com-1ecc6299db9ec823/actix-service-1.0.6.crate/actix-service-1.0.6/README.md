# actix-service

> Service trait and combinators for representing asynchronous request/response operations.

See documentation for detailed explanations these components: [https://docs.rs/actix-service](docs).

[docs]: https://docs.rs/actix-service
