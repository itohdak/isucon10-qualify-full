# Changes

## [1.0.1] - 2020-05-19

* Replace deprecated `net2` crate with `socket2`

* Remove unused `futures` dependency

## [1.0.0] - 2019-12-11

* Update actix-server to 1.0.0

## [1.0.0-alpha.3] - 2019-12-07

* Migrate to tokio 0.2

## [1.0.0-alpha.2] - 2019-12-02

* Re-export `test` attribute macros


## [0.3.0-alpha.1] - 2019-11-22

* Migrate to std::future

## [0.2.0] - 2019-10-14

* Upgrade actix-server and actix-server-config deps


## [0.1.0] - 2019-09-25

* Initial impl
