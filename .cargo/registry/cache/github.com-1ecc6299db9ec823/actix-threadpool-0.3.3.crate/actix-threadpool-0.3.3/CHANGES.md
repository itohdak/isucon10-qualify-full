# Changes

## [0.3.3] - 2020-07-14

### Changed

* Update parking_lot to 0.11

## [0.3.2] - 2020-05-20

## Added

* Implement `std::error::Error` for `BlockingError` [#120]

[#120]: https://github.com/actix/actix-net/pull/120

## [0.3.1] - 2019-12-12

### Changed

* Update parking_lot to 0.10

## [0.3.0] - 2019-12-02

### Changed

* Expect `Result` type as a function return type

## [0.2.0] - 2019-11-21

### Changed

* Migrate to `std::future`

## [0.1.2] - 2019-08-05

### Changed

* Update `derive_more` to 0.15

* Update `parking_lot` to 0.9

## [0.1.1] - 2019-06-05

* Update parking_lot

## [0.1.0] - 2019-03-28

* Move threadpool to separate crate
